import React from 'react'
import { FiHome, FiMoreVertical, FiSettings } from 'react-icons/fi'

function Navbar() {
  return (
    <nav className="bg-white rounded-xl shadow px-6 py-4 flex justify-between">
      <h1 className='text-2xl font-black text'>Tech<span className='text-cyan-500'>.</span>Care</h1>

      <div className='flex gap-6 font-medium'>
    
        <button className='flex items-center gap-2 px-4 py-2 rounded-full hover:bg-cyan-300 transition hover:cursor-pointer'>
            <FiHome size={18}></FiHome>
            <span>Overview</span>
        </button>
        <button className='flex items-center gap-2 px-4 py-2 rounded-full hover:bg-cyan-300 transition hover:cursor-pointer'>
            <FiHome size={18}></FiHome>
            <span>Patients</span>
        </button>
        <button className='flex items-center gap-2 px-4 py-2 rounded-full hover:bg-cyan-300 transition hover:cursor-pointer'>
            <FiHome size={18}></FiHome>
            <span>Schedule</span>
        </button>
        <button className='flex items-center gap-2 px-4 py-2 rounded-full hover:bg-cyan-300 transition hover:cursor-pointer'>
            <FiHome size={18}></FiHome>
            <span>Message</span>
        </button>
        <button className='flex items-center gap-2 px-4 py-2 rounded-full hover:bg-cyan-300 transition hover:cursor-pointer'>
            <FiHome size={18}></FiHome>
            <span>Transactions</span>
        </button>
      </div>

      <div className='flex gap-4 items-center'>
        <img className='rounded-full w-11 h-11 object-cover ' src='src\assets\drjoe.jpg' alt='Loading Image'></img>
        <div className='flex flex-col pr-3 border-r'>
          <span className='font-bold'>Dr. John Doe</span>
          <span className='text-sm text-gray-500'>Cardiologist</span>
        </div>
        <div className='flex gap-2'>
            <FiSettings size={20} className='hover:cursor-pointer'></FiSettings>
            <FiMoreVertical size={20} className='hover:cursor-pointer'></FiMoreVertical>
        </div>

      </div>
    </nav>
  )
}    

export default Navbar
