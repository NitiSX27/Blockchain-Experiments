import React from 'react'
import { FiCalendar, FiDownload, FiHeart, FiPhone, FiShield, FiThermometer, FiUser, FiWind } from 'react-icons/fi'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { usePatients } from '../PatientData/PatientContext'

function Dashboard() {
  const { selectedPatient, loading, error } = usePatients()

  if (loading) {
    return <div className='bg-white rounded-xl p-6 flex-1'>Loading patient data...</div>
  }

  if (error) {
    return <div className='bg-white rounded-xl p-6 flex-1 text-red-500'>{error}</div>
  }

  if (!selectedPatient) {
    return <div className='bg-white rounded-xl p-6 flex-1'>No patient selected</div>
  }

  const history = selectedPatient.diagnosis_history || []
  const latest = history[0]

  const chartData = history.slice(0, 6).reverse().map(item => ({
    name: `${item.month.slice(0, 3)} ${item.year}`,
    systolic: item.blood_pressure.systolic.value,
    diastolic: item.blood_pressure.diastolic.value,
  }))

  return (
    <div className='grid grid-cols-[1fr_350px] gap-6 flex-1'>
      <div className='flex flex-col gap-6'>
        <div className='bg-white rounded-xl p-6'>
          <h2 className='text-xl font-black mb-6'>Diagnosis History</h2>

          <div className='bg-purple-50 rounded-xl p-5 grid grid-cols-[1fr_190px] gap-5'>
            <div>
              <div className='flex justify-between mb-4'>
                <h3 className='font-bold'>Blood Pressure</h3>
                <span className='text-sm text-gray-500'>Last 6 months</span>
              </div>
              <div className='h-64'>
                <ResponsiveContainer width='100%' height='100%'>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray='3 3' vertical={false}></CartesianGrid>
                    <XAxis dataKey='name' fontSize={12}></XAxis>
                    <YAxis fontSize={12}></YAxis>
                    <Tooltip></Tooltip>
                    <Line type='monotone' dataKey='systolic' stroke='#e66ac4' strokeWidth={3} dot={{ r: 5 }}></Line>
                    <Line type='monotone' dataKey='diastolic' stroke='#7b61ff' strokeWidth={3} dot={{ r: 5 }}></Line>
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className='flex flex-col gap-5 pt-10'>
              <div>
                <p className='font-bold text-pink-500'>Systolic</p>
                <h3 className='text-2xl font-black'>{latest?.blood_pressure.systolic.value}</h3>
                <p className='text-sm text-gray-600'>{latest?.blood_pressure.systolic.levels}</p>
              </div>
              <hr></hr>
              <div>
                <p className='font-bold text-indigo-500'>Diastolic</p>
                <h3 className='text-2xl font-black'>{latest?.blood_pressure.diastolic.value}</h3>
                <p className='text-sm text-gray-600'>{latest?.blood_pressure.diastolic.levels}</p>
              </div>
            </div>
          </div>

          <div className='grid grid-cols-3 gap-5 mt-5'>
            <VitalCard title='Respiratory Rate' value={`${latest?.respiratory_rate.value} bpm`} level={latest?.respiratory_rate.levels} bg='bg-cyan-100' icon={<FiWind size={34}></FiWind>}></VitalCard>
            <VitalCard title='Temperature' value={`${latest?.temperature.value} F`} level={latest?.temperature.levels} bg='bg-pink-100' icon={<FiThermometer size={34}></FiThermometer>}></VitalCard>
            <VitalCard title='Heart Rate' value={`${latest?.heart_rate.value} bpm`} level={latest?.heart_rate.levels} bg='bg-rose-100' icon={<FiHeart size={34}></FiHeart>}></VitalCard>
          </div>
        </div>

        <div className='bg-white rounded-xl p-6 h-[330px] overflow-hidden'>
          <h2 className='text-xl font-black mb-5'>Diagnostic List</h2>
          <div className='grid grid-cols-[1fr_2fr_1fr] bg-gray-100 rounded-full py-3 px-5 text-sm font-bold'>
            <span>Problem/Diagnosis</span>
            <span>Description</span>
            <span>Status</span>
          </div>

          <div className='overflow-y-auto h-56'>
            {selectedPatient.diagnostic_list.map(item => (
              <div key={item.name} className='grid grid-cols-[1fr_2fr_1fr] py-4 px-5 border-b text-sm'>
                <span>{item.name}</span>
                <span>{item.description}</span>
                <span>{item.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className='flex flex-col gap-6'>
        <ProfileCard patient={selectedPatient}></ProfileCard>
        <LabResults labs={selectedPatient.lab_results}></LabResults>
      </div>
    </div>
  )
}

function VitalCard({ title, value, level, bg, icon }) {
  return (
    <div className={`${bg} rounded-xl p-5`}>
      <div className='w-16 h-16 rounded-full bg-white flex items-center justify-center mb-4'>{icon}</div>
      <p>{title}</p>
      <h3 className='text-3xl font-black'>{value}</h3>
      <p className='text-sm text-gray-600 mt-3'>{level}</p>
    </div>
  )
}

function ProfileCard({ patient }) {
  return (
    <div className='bg-white rounded-xl p-7'>
      <div className='flex flex-col items-center'>
        <img className='w-44 h-44 rounded-full object-cover mb-5' src={patient.profile_picture} alt={patient.name}></img>
        <h2 className='text-2xl font-black mb-6'>{patient.name}</h2>
      </div>

      <ProfileRow icon={<FiCalendar></FiCalendar>} title='Date Of Birth' text={patient.date_of_birth}></ProfileRow>
      <ProfileRow icon={<FiUser></FiUser>} title='Gender' text={patient.gender}></ProfileRow>
      <ProfileRow icon={<FiPhone></FiPhone>} title='Contact Info.' text={patient.phone_number}></ProfileRow>
      <ProfileRow icon={<FiPhone></FiPhone>} title='Emergency Contacts' text={patient.emergency_contact}></ProfileRow>
      <ProfileRow icon={<FiShield></FiShield>} title='Insurance Provider' text={patient.insurance_type}></ProfileRow>

      <button className='bg-cyan-400 rounded-full px-8 py-3 font-bold mt-5 mx-auto block hover:cursor-pointer'>Show All Information</button>
    </div>
  )
}

function ProfileRow({ icon, title, text }) {
  return (
    <div className='flex gap-4 items-center mb-5'>
      <div className='w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center'>{icon}</div>
      <div>
        <p className='text-sm text-gray-500'>{title}</p>
        <p className='font-bold text-sm'>{text}</p>
      </div>
    </div>
  )
}

function LabResults({ labs }) {
  return (
    <div className='bg-white rounded-xl p-6 h-[280px] overflow-hidden'>
      <h2 className='text-xl font-black mb-4'>Lab Results</h2>
      <div className='overflow-y-auto h-52'>
        {labs.map(lab => (
          <div key={lab} className='flex justify-between items-center p-3 hover:bg-gray-100'>
            <span className='text-sm'>{lab}</span>
            <FiDownload></FiDownload>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Dashboard
