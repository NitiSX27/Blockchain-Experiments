import React from 'react'
import { FiMoreHorizontal, FiSearch } from 'react-icons/fi'
import { usePatients } from '../PatientData/PatientContext'

function PatientSidebar() {
  const { patients, selectedPatient, setSelectedPatient, loading } = usePatients()

  return (
    <div className='bg-white rounded-xl p-5 h-[820px] overflow-hidden'>
      <div className='flex justify-between items-center mb-6'>
        <h2 className='text-xl font-black'>Patients</h2>
        <FiSearch size={20}></FiSearch>
      </div>

      <div className='flex flex-col gap-2 overflow-y-auto h-[735px] pr-1'>
        {loading && <p className='text-gray-500'>Loading...</p>}

        {patients.map(patient => (
          <button
            key={patient.name}
            onClick={() => setSelectedPatient(patient)}
            className={`flex justify-between items-center p-3 rounded-xl text-left hover:cursor-pointer ${selectedPatient?.name === patient.name ? 'bg-cyan-100' : 'hover:bg-gray-100'}`}
          >
            <div className='flex items-center gap-3'>
              <img className='w-12 h-12 rounded-full object-cover' src={patient.profile_picture} alt={patient.name}></img>
              <div>
                <h3 className='font-bold text-sm'>{patient.name}</h3>
                <p className='text-gray-500 text-sm'>{patient.gender}, {patient.age}</p>
              </div>
            </div>
            <FiMoreHorizontal></FiMoreHorizontal>
          </button>
        ))}
      </div>
    </div>
  )
}

export default PatientSidebar
