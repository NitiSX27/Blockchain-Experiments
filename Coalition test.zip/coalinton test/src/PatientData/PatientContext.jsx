import React, { createContext, useContext, useEffect, useState } from 'react'
import { getPatientsData } from './PatientApi'

const PatientContext = createContext()

export const PatientProvider = ({ children }) => {
    const [patients, setPatients] = useState([])
    const [selectedPatient, setSelectedPatient] = useState(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    useEffect(() => {
        const fetchPatients = async () => {
            try {
                const data = await getPatientsData()
                setPatients(data)

                const jessica = data.find(patient => patient.name === 'Jessica Taylor')
                setSelectedPatient(jessica || data[0])
            } catch (err) {
                setError('Something went wrong while getting patients')
            } finally {
                setLoading(false)
            }
        }

        fetchPatients()
    }, [])

    return (
        <PatientContext.Provider value={{ patients, selectedPatient, setSelectedPatient, loading, error }}>
            {children}
        </PatientContext.Provider>
    )
}

export const usePatients = () => {
    return useContext(PatientContext)
}
