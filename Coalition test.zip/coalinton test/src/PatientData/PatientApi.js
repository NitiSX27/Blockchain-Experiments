import axios from "axios";

const api = "https://fedskillstest.coalitiontechnologies.workers.dev"

export const getPatientsData = async () => {
    const response = await axios.get(api,{
        auth: {
            username: "coalition",
            password: "skills-test",
        },
    });
    return response.data;
}
