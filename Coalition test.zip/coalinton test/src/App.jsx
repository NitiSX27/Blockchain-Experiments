import React from 'react'
import Navbar from './componenets/Navbar'
import PatientSidebar from './componenets/PatientSidebar'
import Dashboard from './componenets/Dashboard'
import { PatientProvider } from './PatientData/PatientContext'

function App() {
  return (
    <PatientProvider>
      <div className='bg-gray-100 min-h-screen p-6'>
        <Navbar></Navbar>

        <div className='flex gap-6 mt-6'>
          <div className='w-80'>
            <PatientSidebar></PatientSidebar>
          </div>
          <Dashboard></Dashboard>
        </div>
      </div>
    </PatientProvider>
  )
}

export default App
